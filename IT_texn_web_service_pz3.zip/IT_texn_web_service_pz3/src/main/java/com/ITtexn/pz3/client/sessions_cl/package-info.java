@javax.xml.bind.annotation.XmlSchema(namespace = "http://session.client.pz3.ITtexn.com/")
package com.ITtexn.pz3.client.sessions_cl;
