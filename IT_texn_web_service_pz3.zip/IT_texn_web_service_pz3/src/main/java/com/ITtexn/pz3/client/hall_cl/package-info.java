@javax.xml.bind.annotation.XmlSchema(namespace = "http://hall.service.pz3.ITtexn.com/")
package com.ITtexn.pz3.client.hall_cl;
