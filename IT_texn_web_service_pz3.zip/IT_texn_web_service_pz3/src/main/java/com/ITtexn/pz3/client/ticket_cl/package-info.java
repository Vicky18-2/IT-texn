@javax.xml.bind.annotation.XmlSchema(namespace = "http://ticket.service.pz3.ITtexn.com/")
package com.ITtexn.pz3.client.ticket_cl;
