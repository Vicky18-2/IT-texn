@javax.xml.bind.annotation.XmlSchema(namespace = "http://film_cl.client.pz3.ITtexn.com/")
package com.ITtexn.pz3.client.film_cl;
